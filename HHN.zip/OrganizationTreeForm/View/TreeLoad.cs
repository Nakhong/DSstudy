﻿using OrganizationTreeForm.Model;
using OrganizationTreeForm.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrganizationTreeForm.View
{
    /// <summary>
    /// TreeView node 만들어주기
    /// </summary>
    public class TreeLoad
    {

        public TreeLoad(List<Employee> list, TreeView orgTV) // csv row로 list 추가
        {

        }
    }
}
